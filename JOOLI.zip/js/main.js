import { initAuth } from "./auth.js";
import { initEvents } from "./events.js";
import { initCalendar } from "./calendar.js";
import { initUI } from "./ui.js";

const loginDiv = document.getElementById("loginDiv");
const appDiv = document.getElementById("appDiv");

document.getElementById("darkBtn").onclick =
  ()=>document.body.classList.toggle("dark");

initAuth(()=>{

  loginDiv.style.display="none";
  appDiv.style.display="block";

  initUI();
  initEvents();
  initCalendar();

});