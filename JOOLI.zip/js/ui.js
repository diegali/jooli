export function initUI() {
  document.getElementById("addBtn").style.display = "inline-block";
  document.getElementById("updateBtn").style.display = "none";
  let selectedCard = null;

export function highlightCard(id){

const cards = document.querySelectorAll("#eventsList .card");

cards.forEach(card=>{

if(card.dataset.id === id){

if(selectedCard) selectedCard.classList.remove("selected");

card.classList.add("selected");

selectedCard = card;

}

});

}
}